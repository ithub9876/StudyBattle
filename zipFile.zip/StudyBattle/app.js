firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();

let isSignup = false;
let currentUser = null;
let currentData = null;

let selectedMinutes = 15;
let timerSeconds = 900;
let timerInterval = null;
let timerRunning = false;

let currentRoomId = null;
let currentRoomRole = null;
let roomUnsubscribe = null;
let roomTimerInterval = null;
let latestRoomData = null;

const authPage = document.getElementById("authPage");
const mainApp = document.getElementById("mainApp");
const authTitle = document.getElementById("authTitle");
const authBtn = document.getElementById("authBtn");
const switchAuth = document.getElementById("switchAuth");
const usernameInput = document.getElementById("usernameInput");
const emailInput = document.getElementById("emailInput");
const passwordInput = document.getElementById("passwordInput");
const authMsg = document.getElementById("authMsg");

const homeScreen = document.getElementById("homeScreen");
const battleScreen = document.getElementById("battleScreen");
const forestScreen = document.getElementById("forestScreen");
const profileScreen = document.getElementById("profileScreen");
const archivesScreen = document.getElementById("archivesScreen");
const timerPage = document.getElementById("timerPage");
const navButtons = document.querySelectorAll(".navBtn");

function defaultUserData(user, username) {
  return {
    uid: user.uid,
    username: username || "Warrior",
    email: user.email,
    totalStudyMinutes: 0,
    coins: 0,
    gems: 0,
    level: 1,
    totalXP: 0,
    trees: 0,
    deadTrees: 0,
    castleHealth: 100,
    armyPower: 0,
    streak: 0,
    lastStudyDate: "",
    createdAt: Date.now()
  };
}

switchAuth.onclick = function () {
  isSignup = !isSignup;
  authMsg.innerText = "";

  if (isSignup) {
    authTitle.innerText = "Create Account";
    authBtn.innerText = "Create Account";
    switchAuth.innerText = "Already have account? Login";
    usernameInput.classList.remove("hidden");
  } else {
    authTitle.innerText = "Welcome Back";
    authBtn.innerText = "Continue";
    switchAuth.innerText = "Create account";
    usernameInput.classList.add("hidden");
  }
};

authBtn.onclick = async function () {
  const username = usernameInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  authMsg.innerText = "";

  if (!email || !password) {
    authMsg.innerText = "Enter email and password";
    return;
  }

  if (password.length < 6) {
    authMsg.innerText = "Password must be at least 6 characters";
    return;
  }

  if (isSignup && !username) {
    authMsg.innerText = "Enter username";
    return;
  }

  try {
    authBtn.disabled = true;
    authBtn.innerText = "Please wait...";

    if (isSignup) {
      const result = await auth.createUserWithEmailAndPassword(email, password);
      await db.collection("users").doc(result.user.uid).set(
        defaultUserData(result.user, username)
      );
    } else {
      await auth.signInWithEmailAndPassword(email, password);
    }
  } catch (error) {
    authMsg.innerText = error.message;
  }

  authBtn.disabled = false;
  authBtn.innerText = isSignup ? "Create Account" : "Continue";
};

auth.onAuthStateChanged(async function (user) {
  try {
    if (user) {
  resetBattleUI();

  currentUser = user;
  await loadUserData();

authPage.style.display = "none";
mainApp.style.display = "block";

showHomeScreen();
await loadActiveBattleRoom();
    } else {
      currentUser = null;
      currentData = null;
      authPage.style.display = "block";
      mainApp.style.display = "none";
    }
  } catch (error) {
    alert(error.message);
  }
});

async function loadUserData() {
  const ref = db.collection("users").doc(currentUser.uid);
  const snap = await ref.get();

  if (!snap.exists) {
    await ref.set(defaultUserData(currentUser, "Warrior"));
  }

  const freshSnap = await ref.get();

  currentData = {
    ...defaultUserData(currentUser, "Warrior"),
    ...freshSnap.data()
  };

  updateUI();
  updateAllScreens();
}

function updateUI() {
  document.getElementById("homeUsername").innerText = currentData.username;
  document.getElementById("homeLevel").innerText = currentData.level;
  document.getElementById("homeCoins").innerText = currentData.coins;
  document.getElementById("homeTotal").innerText = currentData.totalStudyMinutes + " min";
  document.getElementById("forestCount").innerText = currentData.trees + " Trees";
  document.getElementById("armyPower").innerText = currentData.armyPower + " Power";
  document.getElementById("streakText").innerText = currentData.streak + " Days";
  document.getElementById("castleHealthText").innerText = currentData.castleHealth + "%";
  document.getElementById("castleProgress").style.width = currentData.castleHealth + "%";
  const armyBtn = document.getElementById("armyUpgradeBtn");
const defenseBtn = document.getElementById("defenseUpgradeBtn");

if(armyBtn){
  armyBtn.innerText = getArmyUpgradeCost() + " Coins";
}

if(defenseBtn){
  defenseBtn.innerText = getDefenseUpgradeCost() + " Coins";
}
}

function hideAllScreens() {
  homeScreen.style.display = "none";
  battleScreen.style.display = "none";
  forestScreen.style.display = "none";
  profileScreen.style.display = "none";
  if (archivesScreen) archivesScreen.style.display = "none";
}

function clearNav() {
  navButtons.forEach(btn => btn.classList.remove("activeNav"));
}

function showHomeScreen() {
  hideAllScreens();
  clearNav();
  navButtons[0].classList.add("activeNav");
  homeScreen.style.display = "block";
}

function showBattleScreen() {
  hideAllScreens();
  clearNav();
  navButtons[1].classList.add("activeNav");
  battleScreen.style.display = "block";
}

function showForestScreen() {
  hideAllScreens();
  clearNav();
  navButtons[2].classList.add("activeNav");
  forestScreen.style.display = "block";
}

function showProfileScreen() {
  hideAllScreens();
  clearNav();
  navButtons[3].classList.add("activeNav");
  profileScreen.style.display = "block";
  updateProfileUI();
  loadFriendSystem();
}

function switchScreen(screenId) {
  hideAllScreens();
  document.getElementById(screenId).style.display = "block";
}

navButtons[0].onclick = showHomeScreen;
navButtons[1].onclick = showBattleScreen;
navButtons[2].onclick = showForestScreen;
navButtons[3].onclick = showProfileScreen;

function updateProfileUI() {
  if (!currentData) return;

  document.getElementById("profileUsername").innerText = currentData.username;
  document.getElementById("profileStudy").innerText =
    Math.round(currentData.totalStudyMinutes || 0) + " min";
  document.getElementById("profileCoins").innerText = currentData.coins;
  document.getElementById("profileArmy").innerText = currentData.armyPower;
  document.getElementById("profileLevel").innerText = currentData.level;
  document.getElementById("profileXP").innerText =
    Math.round(currentData.totalXP || 0);
    const totalXP = currentData.totalXP || 0;

const currentLevel = currentData.level || 1;

const currentLevelXP =
  getXPRequired(currentLevel - 1);

const nextLevelXP =
  getXPRequired(currentLevel);

const progressXP =
  totalXP - currentLevelXP;

const neededXP =
  nextLevelXP - currentLevelXP;

const progressPercent =
  (progressXP / neededXP) * 100;

document.getElementById("xpProgressText").innerText =
  `${Math.round(progressXP)} / ${neededXP} XP`;

document.getElementById("xpFill").style.width =
  `${progressPercent}%`;
}

function updateForestUI() {
  if (!currentData) return;

  document.getElementById("forestTreeCount").innerText =
    currentData.trees || 0;

  document.getElementById("deadTreeCount").innerText =
    currentData.deadTrees || 0;

  renderForestTrees();
}

function updateBattleUI() {
  if (!currentData) return;

  document.getElementById("battleArmyText").innerText = currentData.armyPower;
  document.getElementById("battleCastleText").innerText = currentData.castleHealth;
}

function updateAllScreens() {
  updateProfileUI();
  updateForestUI();
  updateBattleUI();
}

function updateTimerDisplay() {
  const minutes = Math.floor(timerSeconds / 60).toString().padStart(2, "0");
  const seconds = (timerSeconds % 60).toString().padStart(2, "0");
  document.getElementById("timerDisplay").innerText = minutes + ":" + seconds;
}

updateTimerDisplay();
updateSessionPreview();

function selectMinutes(minutes) {
  selectedMinutes = minutes;
  timerSeconds = minutes * 60;
  updateTimerDisplay();
  updateSessionPreview();
}

window.selectMinutes = selectMinutes;

function selectCustom(){
  const value = Number(
    document.getElementById("customMinutes").value
  );

  if(!value || value <= 0){
    alert("Invalid minutes");
    return;
  }

  selectedMinutes = Math.round(value);

  timerSeconds = selectedMinutes * 60;

  updateTimerDisplay();
  updateSessionPreview();
}

window.selectCustom = selectCustom;

function openTimer() {
  timerPage.style.display = "block";
}

window.openTimer = openTimer;

function closeTimer() {
  if (timerRunning) {
    alert("Session running");
    return;
  }

  timerPage.style.display = "none";
}

window.closeTimer = closeTimer;

function startTimer() {
  if (timerRunning) return;

  timerRunning = true;
  timerSeconds = selectedMinutes * 60;
  updateTimerDisplay();

  document.getElementById("startTimerBtn").classList.add("hiddenPage");
  document.getElementById("quitSoloBtn").classList.remove("hiddenPage");

  timerInterval = setInterval(function () {
    timerSeconds--;
    updateTimerDisplay();

    if (timerSeconds <= 0) {
      completeSession();
    }
  }, 1000);
}

window.startTimer = startTimer;

async function completeSession() {
  clearInterval(timerInterval);
  timerRunning = false;
const today = getTodayDateString();

const yesterdayDate = new Date();
yesterdayDate.setDate(yesterdayDate.getDate() - 1);

const yesterday =
  yesterdayDate.getFullYear() + "-" +
  String(yesterdayDate.getMonth() + 1).padStart(2,"0") + "-" +
  String(yesterdayDate.getDate()).padStart(2,"0");

let streak = currentData.streak || 0;

if(currentData.lastStudyDate === today){

  // same day → keep streak

}
else if(currentData.lastStudyDate === yesterday){

  streak += 1;

}
else{

  streak = 1;
}
  let gainedXP =
    getXPForSession(selectedMinutes);

  const streakBonus =
    getStreakBonusPercent();

  gainedXP += Math.floor(
    gainedXP * (streakBonus / 100)
  );

  const totalXP = (currentData.totalXP || 0) + gainedXP;

  const studyMinutes = (currentData.totalStudyMinutes || 0) + selectedMinutes;

  const gainedCoins = Math.floor(selectedMinutes * 1.5);

  const coins = (currentData.coins || 0) + gainedCoins;

  let treeGain = 0;

  if(selectedMinutes >= 15){
    treeGain = 1;
  }

  if(selectedMinutes >= 60){
    treeGain = 2;
  }

  if(selectedMinutes >= 120){
    treeGain = 3;
  }

  const trees = (currentData.trees || 0) + treeGain;

  let tree = "None";

  if(selectedMinutes >= 15){
    tree = "Seed";
  }

  if(selectedMinutes >= 30){
    tree = "Young Tree";
  }

  if(selectedMinutes >= 60){
    tree = "Full Tree";
  }

  if(selectedMinutes >= 120){
    tree = "Rare Tree";
  }

  const army = (currentData.armyPower || 0) + Math.floor(selectedMinutes / 5);

  const level = calculateLevel(totalXP);

  await db.collection("users").doc(currentUser.uid).update({
  totalStudyMinutes: studyMinutes,
  totalXP: totalXP,
  coins: coins,
  trees: trees,
  armyPower: army,
  level: level,
  streak: streak,
  lastStudyDate: today
});

const earnedTreeType =
  getTreeTypeFromMinutes(selectedMinutes);

if(earnedTreeType){
  const oldForestTrees =
    currentData.forestTrees || [];

  if(oldForestTrees.length < forestSpots.length){
    const spot =
      forestSpots[oldForestTrees.length];

    const newForestTree = {
      id: Date.now().toString(),
      type: earnedTreeType,
      x: spot.x,
      y: spot.y,
      minutes: selectedMinutes,
      createdAt: Date.now()
    };

    await db.collection("users").doc(currentUser.uid).update({
      forestTrees: [
        ...oldForestTrees,
        newForestTree
      ]
    });
  }
}

  await loadUserData();

  document.getElementById("startTimerBtn").classList.remove("hiddenPage");
  document.getElementById("quitSoloBtn").classList.add("hiddenPage");

  showRewardModal({
    minutes: selectedMinutes,
    xp: gainedXP,
    coins: gainedCoins,
    tree: tree,
    streakBonus: streakBonus
  });
}

function generateRoomId() {
  return "SB" + Math.floor(100000 + Math.random() * 900000);
}

async function createBattleRoom() {
  const targetHours = Number(document.getElementById("battleTargetHours").value);
  const password = document.getElementById("battlePassword").value.trim();

  if (!targetHours || targetHours <= 0) {
    alert("Enter valid target hours");
    return;
  }

  const roomId = generateRoomId();

  await db.collection("battleRooms").doc(roomId).set({
    roomId,
    targetHours,
    password,
    status: "waiting",

    attackerUid: currentUser.uid,
    attackerName: currentData.username,
    attackerConfirmed: false,
    attackerConfirmedAt: null,
    attackerLeft: false,
    attackerLeftAt: null,

    defenderUid: null,
    defenderName: null,
    defenderConfirmed: false,
    defenderConfirmedAt: null,
    defenderLeft: false,
    defenderLeftAt: null,

    createdAt: Date.now(),
    startedAt: null,
confirmDeadlineAt: null,
endedAt: null,
scorecard: null,
participants: [currentUser.uid]
    
  });

  currentRoomId = roomId;
  currentRoomRole = "attacker";

  showActiveRoom(roomId);
}

window.createBattleRoom = createBattleRoom;

async function joinBattleRoom() {
  const roomId = document.getElementById("joinRoomId").value.trim().toUpperCase();
  const password = document.getElementById("joinRoomPassword").value.trim();

  if (!roomId) {
    alert("Enter room ID");
    return;
  }

  const roomRef = db.collection("battleRooms").doc(roomId);
  const snap = await roomRef.get();

  if (!snap.exists) {
    alert("Room not found");
    return;
  }

  const room = snap.data();

  if (room.attackerUid === currentUser.uid) {
    alert("You cannot join your own room. Use Add Test Rival for testing.");
    return;
  }

  if (room.password && room.password !== password) {
    alert("Wrong password");
    return;
  }

  if (room.defenderUid) {
    alert("Room already full");
    return;
  }

  await roomRef.update({
  defenderUid: currentUser.uid,
  defenderName: currentData.username,
  status: "active",
  startedAt: Date.now(),
confirmDeadlineAt:
  Date.now() + (Number(room.targetHours) * 60 * 60 * 1000) + (10 * 60 * 1000),
participants: firebase.firestore.FieldValue.arrayUnion(currentUser.uid)
});

  currentRoomId = roomId;
  currentRoomRole = "defender";

  showActiveRoom(roomId);
}

window.joinBattleRoom = joinBattleRoom;

function showActiveRoom(roomId) {
  document.getElementById("activeRoomCard").classList.remove("hiddenPage");
  document.getElementById("activeRoomCode").innerText = "WAR ROOM • " + roomId;
  listenToRoom(roomId);
  document.getElementById("activeRoomCard").scrollIntoView({ behavior: "smooth" });
}

function listenToRoom(roomId) {
  if (roomUnsubscribe) roomUnsubscribe();

  roomUnsubscribe = db.collection("battleRooms").doc(roomId)
    .onSnapshot(function (snap) {
      if (!snap.exists) return;

      const room = snap.data();
      latestRoomData = room;

      document.getElementById("activeRoomTitle").innerText =
        room.attackerName + " vs " + (room.defenderName || "Awaiting Rival");

      document.getElementById("activeRoomTarget").innerText =
        "Target: " + room.targetHours + "h";

      updateBattleStatuses(room);
      startRoomTimer(room);

      if (room.status === "ended" && room.scorecard) {
        showScoreCard(room.scorecard);
      }
    });
}

function startRoomTimer(room) {
  if (roomTimerInterval) clearInterval(roomTimerInterval);

  roomTimerInterval = setInterval(function () {
    updateRoomTimer(room);
  }, 1000);

  updateRoomTimer(room);
}

function updateRoomTimer(room) {
  const timerBox = document.getElementById("activeRoomTimer");
  const confirmBtn = document.getElementById("confirmStudyBtn");

  if (!room.startedAt) {
    timerBox.innerText = "Waiting";
    confirmBtn.classList.add("hiddenPage");
    return;
  }

  if (room.status === "ended") {
    timerBox.innerText = "Ended";
    confirmBtn.classList.add("hiddenPage");
    return;
  }

  const targetMs = room.targetHours * 60 * 60 * 1000;
  const battleEndAt = room.startedAt + targetMs;
  const confirmDeadlineAt =
    room.confirmDeadlineAt || battleEndAt + (10 * 60 * 1000);

  const now = Date.now();

  if (now >= confirmDeadlineAt) {
    autoEndBattleIfDeadlinePassed(room);
    timerBox.innerText = "Deadline Passed";
    confirmBtn.classList.add("hiddenPage");
    return;
  }

  let leftMs = 0;
  let label = "";

  if (now < battleEndAt) {
    leftMs = battleEndAt - now;
    label = "";
  } else {
    leftMs = confirmDeadlineAt - now;
    label = "Confirm ";
  }

  const hours = Math.floor(leftMs / 3600000);
  const minutes = Math.floor((leftMs % 3600000) / 60000);
  const seconds = Math.floor((leftMs % 60000) / 1000);

  timerBox.innerText =
    label +
    String(hours).padStart(2, "0") + ":" +
    String(minutes).padStart(2, "0") + ":" +
    String(seconds).padStart(2, "0");

  const completedHours =
    Math.min(room.targetHours, (now - room.startedAt) / 3600000).toFixed(1);

  document.getElementById("attackerProgress").innerText =
    completedHours + "h";

  document.getElementById("defenderProgress").innerText =
    room.defenderUid ? completedHours + "h" : "0h";

  const myConfirmed =
    currentRoomRole === "attacker"
      ? room.attackerConfirmed
      : room.defenderConfirmed;

  const myLeft =
    currentRoomRole === "attacker"
      ? room.attackerLeft
      : room.defenderLeft;

  if (now >= battleEndAt && !myConfirmed && !myLeft) {
    confirmBtn.classList.remove("hiddenPage");
  } else {
    confirmBtn.classList.add("hiddenPage");
  }
}

function updateBattleStatuses(room) {
  document.getElementById("attackerStatus").innerText =
    getPlayerStatus(room.attackerConfirmed, room.attackerConfirmedAt, room.attackerLeft, room.attackerLeftAt);

  document.getElementById("defenderStatus").innerText =
    room.defenderUid
      ? getPlayerStatus(room.defenderConfirmed, room.defenderConfirmedAt, room.defenderLeft, room.defenderLeftAt)
      : "Awaiting rival";
}

function getPlayerStatus(confirmed, confirmedAt, left, leftAt) {
  if (confirmed) return "Confirmed at " + formatTime(confirmedAt);
  if (left) return "Left at " + formatTime(leftAt);
  return "In battle";
}

async function confirmStudyDone() {
  if (!currentRoomId || !latestRoomData) return;

  const update = {};

  if (currentRoomRole === "attacker") {
    update.attackerConfirmed = true;
    update.attackerConfirmedAt = Date.now();
  } else {
    update.defenderConfirmed = true;
    update.defenderConfirmedAt = Date.now();
  }

  await db.collection("battleRooms").doc(currentRoomId).update(update);
  await tryGenerateScorecard();
}

window.confirmStudyDone = confirmStudyDone;

async function leaveBattleRoom() {
  if (!currentRoomId) return;

  const update = {};

  if (currentRoomRole === "attacker") {
    update.attackerLeft = true;
    update.attackerLeftAt = Date.now();
  } else {
    update.defenderLeft = true;
    update.defenderLeftAt = Date.now();
  }

  await db.collection("battleRooms").doc(currentRoomId).update(update);
  await tryGenerateScorecard();
}

window.leaveBattleRoom = leaveBattleRoom;

async function tryGenerateScorecard() {
  if (!currentRoomId) return;

  const roomRef = db.collection("battleRooms").doc(currentRoomId);
  const snap = await roomRef.get();

  if (!snap.exists) return;

  const room = snap.data();

  if (room.status === "ended") return;

  const attackerDone = room.attackerConfirmed || room.attackerLeft;
  const defenderDone = room.defenderConfirmed || room.defenderLeft;

  if (!attackerDone || !defenderDone) return;

  const scorecard = await buildScorecardWithEffects(room);

  await roomRef.update({
    status: "ended",
    endedAt: Date.now(),
    scorecard
  });
}

function buildScorecard(room) {
  let resultTitle = "";
  let resultLine = "";

  const attackerConfirmed = room.attackerConfirmed === true;
  const defenderConfirmed = room.defenderConfirmed === true;

  if (attackerConfirmed && !defenderConfirmed) {
    resultTitle = "Attack Successful";
    resultLine =
      room.defenderName +
      " failed to confirm before the deadline. Castle integrity was damaged.";
  } else if (!attackerConfirmed && defenderConfirmed) {
    resultTitle = "Defense Successful";
    resultLine =
      room.attackerName +
      " failed to confirm before the deadline. The siege collapsed.";
  } else if (attackerConfirmed && defenderConfirmed) {
    resultTitle = "Castle Defended";
    resultLine =
      "Both warriors confirmed the target. The defender holds the kingdom.";
  } else {
    resultTitle = "War Abandoned";
    resultLine =
      "Neither side confirmed before the deadline. No victory was claimed.";
  }

  return {
    resultTitle,
    resultLine,
    attackerName: room.attackerName,
    defenderName: room.defenderName || "Unknown",
    targetHours: room.targetHours,
    attackerStatus: attackerConfirmed ? "Confirmed" : "Not Confirmed",
    defenderStatus: defenderConfirmed ? "Confirmed" : "Not Confirmed",
    attackerTime: room.attackerConfirmedAt || room.attackerLeftAt,
    defenderTime: room.defenderConfirmedAt || room.defenderLeftAt,
    createdAt: Date.now()
  };
}

function showScoreCard(scorecard) {
  const box = document.getElementById("scoreCardBox");
  box.classList.remove("hiddenPage");

  box.innerHTML = `
    <div class="scoreHeader">
      <div>
        <span>WAR REPORT</span>
        <h3>${scorecard.resultTitle}</h3>
      </div>
      <i class="ri-sword-line"></i>
    </div>

    <div class="scoreDuel">
      <div class="scorePlayer">
        <span>ATTACKER</span>
        <h4>${scorecard.attackerName}</h4>
        <p>${scorecard.attackerStatus}</p>
        <small>${formatTime(scorecard.attackerTime)}</small>
      </div>

      <div class="scoreDivider">VS</div>

      <div class="scorePlayer">
        <span>DEFENDER</span>
        <h4>${scorecard.defenderName}</h4>
        <p>${scorecard.defenderStatus}</p>
        <small>${formatTime(scorecard.defenderTime)}</small>
      </div>
    </div>

    <div class="scoreResult">
  ${scorecard.resultLine}
</div>

<div class="scoreEffects">
  <div>
    <span>Attacker XP</span>
    <b>+${scorecard.attackerXP || 0}</b>
  </div>

  <div>
    <span>Defender XP</span>
    <b>+${scorecard.defenderXP || 0}</b>
  </div>
  <div>
  <span>Attacker Coins</span>
  <b>+${scorecard.attackerCoins || 0}</b>
</div>

<div>
  <span>Defender Coins</span>
  <b>+${scorecard.defenderCoins || 0}</b>
</div>

  <div>
    <span>Castle Damage</span>
    <b>-${scorecard.defenderCastleDamage || 0}%</b>
  </div>

  <div>
    <span>Army Loss</span>
    <b>-${scorecard.attackerArmyLoss || 0}</b>
  </div>
</div>
  `;
}



async function showWarArchives() {
  if (!archivesScreen) {
    alert("Archives screen missing");
    return;
  }

  switchScreen("archivesScreen");

  const list = document.getElementById("archivesList");

  list.innerHTML = `
    <div class="glassCard archiveEmpty">
      <i class="ri-loader-4-line"></i>
      <h3>Loading Wars</h3>
    </div>
  `;

  try {
    const snapshot = await db.collection("battleRooms")
  .where("participants", "array-contains", currentUser.uid)
  .where("status", "==", "ended")
  .limit(20)
  .get();

    if (snapshot.empty) {
      list.innerHTML = `
        <div class="glassCard archiveEmpty">
          <i class="ri-scroll-to-bottom-line"></i>
          <h3>No Wars Recorded</h3>
          <p>Complete battles to build history.</p>
        </div>
      `;
      return;
    }

    let rooms = [];

    snapshot.forEach(doc => {
      rooms.push(doc.data());
    });

    rooms.sort((a, b) => {
      return (b.endedAt || 0) - (a.endedAt || 0);
    });

    let html = "";

    rooms.forEach(room => {
      if (!room.scorecard) return;

      const s = room.scorecard;

      html += `
        <div class="archiveCard">
          <div class="archiveTop">
            <div>
              <h3>${s.resultTitle}</h3>
              <div class="archiveDate">
                ${room.endedAt ? new Date(room.endedAt).toLocaleDateString() : "--"}
              </div>
            </div>

            <div class="archiveBadge">
              ARCHIVED
            </div>
          </div>

          <div class="archivePlayers">
            <div class="archivePlayer">
              <span>ATTACKER</span>
              <h4>${s.attackerName}</h4>
              <p>${s.attackerStatus}</p>
            </div>

            <div class="archiveVS">VS</div>

            <div class="archivePlayer">
              <span>DEFENDER</span>
              <h4>${s.defenderName}</h4>
              <p>${s.defenderStatus}</p>
            </div>
          </div>

          <div class="archiveBottom">
            ${s.resultLine}
          </div>
        </div>
      `;
    });

    list.innerHTML = html || `
      <div class="glassCard archiveEmpty">
        <h3>No Scorecards Found</h3>
      </div>
    `;

  } catch (error) {
    list.innerHTML = `
      <div class="glassCard archiveEmpty">
        <h3>Archive Error</h3>
        <p>${error.message}</p>
      </div>
    `;
  }
}

window.showWarArchives = showWarArchives;

window.showWarArchives = showWarArchives;

function formatTime(ms) {
  if (!ms) return "--";

  const date = new Date(ms);

  return date.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
}
/* FRIEND SYSTEM */

async function updateUsernameSearchKey(){
  if(!currentUser || !currentData) return;

  await db.collection("users").doc(currentUser.uid).set({
    usernameLower: currentData.username.toLowerCase()
  }, { merge:true });
}

async function sendFriendRequest(){
  const input = document.getElementById("friendUsernameInput");
  const msg = document.getElementById("friendMsg");

  const username = input.value.trim();

  msg.innerText = "";

  if(!username){
    msg.innerText = "Enter username";
    return;
  }

  const snap = await db.collection("users")
    .where("usernameLower", "==", username.toLowerCase())
    .limit(1)
    .get();

  if(snap.empty){
    msg.innerText = "User not found";
    return;
  }

  const targetDoc = snap.docs[0];
  const target = targetDoc.data();

  if(target.uid === currentUser.uid){
    msg.innerText = "You cannot add yourself";
    return;
  }

  await db.collection("friendRequests").add({
    fromUid: currentUser.uid,
    fromUsername: currentData.username,
    toUid: target.uid,
    toUsername: target.username,
    status: "pending",
    createdAt: Date.now()
  });

  msg.innerText = "Friend request sent";
  input.value = "";
}

window.sendFriendRequest = sendFriendRequest;

async function loadFriendRequests(){
  const box = document.getElementById("friendRequestsList");
  if(!box || !currentUser) return;

  const snap = await db.collection("friendRequests")
    .where("toUid", "==", currentUser.uid)
    .where("status", "==", "pending")
    .get();

  if(snap.empty){
    box.innerHTML = `<div class="friendItem"><p>No pending requests</p></div>`;
    return;
  }

  let html = "";

  snap.forEach(doc => {
    const r = doc.data();

    html += `
      <div class="friendItem">
        <div class="friendItemTop">
          <div>
            <h4>${r.fromUsername}</h4>
            <p>Wants to join your kingdom circle</p>
          </div>

          <button class="friendAction" onclick="acceptFriendRequest('${doc.id}')">
            Accept
          </button>
        </div>
      </div>
    `;
  });

  box.innerHTML = html;
}

async function acceptFriendRequest(requestId){
  const ref = db.collection("friendRequests").doc(requestId);
  const snap = await ref.get();

  if(!snap.exists) return;

  const r = snap.data();

  await db.collection("users").doc(currentUser.uid)
    .collection("friends").doc(r.fromUid).set({
      uid: r.fromUid,
      username: r.fromUsername,
      addedAt: Date.now()
    });

  await db.collection("users").doc(r.fromUid)
    .collection("friends").doc(currentUser.uid).set({
      uid: currentUser.uid,
      username: currentData.username,
      addedAt: Date.now()
    });

  await ref.update({
    status:"accepted",
    acceptedAt:Date.now()
  });

  loadFriendRequests();
  loadFriends();
}

window.acceptFriendRequest = acceptFriendRequest;

async function loadFriends(){
  const box = document.getElementById("friendsList");
  if(!box || !currentUser) return;

  const snap = await db.collection("users")
    .doc(currentUser.uid)
    .collection("friends")
    .get();

  if(snap.empty){
    box.innerHTML = `<div class="friendItem"><p>No friends yet</p></div>`;
    return;
  }

  let html = "";

  snap.forEach(doc => {
    const f = doc.data();

    html += `
      <div class="friendItem" onclick="openFriendProfile('${f.uid}')">
        <div class="friendItemTop">
          <div>
            <h4>${f.username}</h4>
            <p>Friend kingdom connected</p>
          </div>

<button class="friendAction" onclick="inviteFriendToBattle('${f.uid}', '${f.username}')">
  Invite
</button>
        </div>
      </div>
    `;
  });

  box.innerHTML = html;
}

async function loadFriendSystem(){
  await updateUsernameSearchKey();

  try{
    await loadFriendRequests();
  }catch(e){
    console.log("Friend requests error:", e);
  }

  try{
    await loadBattleInvites();
  }catch(e){
    console.log("Battle invites error:", e);

    const box = document.getElementById("battleInvitesList");
    if(box){
      box.innerHTML = `<div class="friendItem"><p>No battle invites</p></div>`;
    }
  }

  try{
    await loadFriends();
  }catch(e){
    console.log("Friends error:", e);
  }
}
function logout() {
  resetBattleUI();

  emailInput.value = "";
  passwordInput.value = "";
  usernameInput.value = "";
  authMsg.innerText = "";

  auth.signOut();
}

window.logout = logout;
function resetBattleUI(){
  currentRoomId = null;
  currentRoomRole = null;
  latestRoomData = null;

  if(roomUnsubscribe){
    roomUnsubscribe();
    roomUnsubscribe = null;
  }

  if(roomTimerInterval){
    clearInterval(roomTimerInterval);
    roomTimerInterval = null;
  }

  const activeRoomCard = document.getElementById("activeRoomCard");
  if(activeRoomCard){
    activeRoomCard.classList.add("hiddenPage");
  }

  const scoreCardBox = document.getElementById("scoreCardBox");
  if(scoreCardBox){
    scoreCardBox.classList.add("hiddenPage");
  }

  const fields = [
    "battleTargetHours",
    "battlePassword",
    "joinRoomId",
    "joinRoomPassword"
  ];

  fields.forEach(id => {
    const el = document.getElementById(id);
    if(el) el.value = "";
  });

  const activeRoomTitle = document.getElementById("activeRoomTitle");
  if(activeRoomTitle) activeRoomTitle.innerText = "Kingdom War";

  const activeRoomCode = document.getElementById("activeRoomCode");
  if(activeRoomCode) activeRoomCode.innerText = "WAR ROOM";

  const activeRoomTimer = document.getElementById("activeRoomTimer");
  if(activeRoomTimer) activeRoomTimer.innerText = "Waiting";

  const attackerProgress = document.getElementById("attackerProgress");
  if(attackerProgress) attackerProgress.innerText = "0h";

  const defenderProgress = document.getElementById("defenderProgress");
  if(defenderProgress) defenderProgress.innerText = "0h";

  const attackerStatus = document.getElementById("attackerStatus");
  if(attackerStatus) attackerStatus.innerText = "Waiting";

  const defenderStatus = document.getElementById("defenderStatus");
  if(defenderStatus) defenderStatus.innerText = "Waiting";
}
async function loadActiveBattleRoom(){
  if(!currentUser) return;

  const snap = await db.collection("battleRooms")
    .where("participants", "array-contains", currentUser.uid)
    .where("status", "in", ["waiting", "active"])
    .limit(1)
    .get();

  if(snap.empty) return;

  const roomDoc = snap.docs[0];
  const room = roomDoc.data();

  currentRoomId = room.roomId;

  if(room.attackerUid === currentUser.uid){
    currentRoomRole = "attacker";
  } else if(room.defenderUid === currentUser.uid){
    currentRoomRole = "defender";
  }

  showActiveRoom(currentRoomId);
}
let selectedInviteFriend = null;

function inviteFriendToBattle(friendUid, friendUsername){
  selectedInviteFriend = {
    uid: friendUid,
    username: friendUsername
  };

  document.getElementById("inviteFriendName").innerText =
    "Invite " + friendUsername;

  document.getElementById("inviteTargetHours").value = "";

  document.getElementById("inviteModal").classList.remove("hiddenPage");
}

window.inviteFriendToBattle = inviteFriendToBattle;

function closeInviteModal(){
  document.getElementById("inviteModal").classList.add("hiddenPage");
}

window.closeInviteModal = closeInviteModal;

async function sendBattleInviteFromModal(){

  const targetHours = Number(
    document.getElementById("inviteTargetHours").value
  );

  if(!selectedInviteFriend){
    alert("No friend selected");
    return;
  }

  if(!targetHours || targetHours <= 0){
    alert("Enter valid target hours");
    return;
  }

  try{

    await db.collection("battleInvites").add({
      fromUid: currentUser.uid,
      fromUsername: currentData.username,
      toUid: selectedInviteFriend.uid,
      toUsername: selectedInviteFriend.username,
      targetHours: targetHours,
      status: "pending",
      createdAt: Date.now()
    });

    const status = document.getElementById("inviteStatus");

status.innerText = "Battle invite sent";
status.classList.add("success");

setTimeout(function(){
  closeInviteModal();
  status.innerText = "";
  status.classList.remove("success");
}, 900);

  }catch(error){

    alert(error.message);

  }
}

window.sendBattleInviteFromModal = sendBattleInviteFromModal;
async function loadBattleInvites(){
  const box = document.getElementById("battleInvitesList");
  if(!box || !currentUser) return;

  const snap = await db.collection("battleInvites")
    .where("toUid", "==", currentUser.uid)
    .where("status", "==", "pending")
    .get();

  if(snap.empty){
    box.innerHTML = `<div class="friendItem"><p>No battle invites</p></div>`;
    return;
  }

  let html = "";

  snap.forEach(doc => {
    const invite = doc.data();

    html += `
      <div class="friendItem">
        <div>
          <h4>${invite.fromUsername}</h4>
          <p>Target: ${invite.targetHours}h battle</p>
        </div>

        <div class="friendInviteActions">
          <button class="friendAction" onclick="acceptBattleInvite('${doc.id}')">
            Accept
          </button>

          <button class="declineAction" onclick="declineBattleInvite('${doc.id}')">
            Decline
          </button>
        </div>
      </div>
    `;
  });

  box.innerHTML = html;
}



async function declineBattleInvite(inviteId){
  await db.collection("battleInvites").doc(inviteId).update({
    status: "declined",
    declinedAt: Date.now()
  });

  loadBattleInvites();
}

window.declineBattleInvite = declineBattleInvite;
async function acceptBattleInvite(inviteId){
  const ref = db.collection("battleInvites").doc(inviteId);
  const snap = await ref.get();

  if(!snap.exists){
    alert("Invite not found");
    return;
  }

  const invite = snap.data();

  if(invite.status !== "pending"){
    alert("Invite already handled");
    return;
  }

  const roomId = generateRoomId();

  await db.collection("battleRooms").doc(roomId).set({
    roomId: roomId,
    targetHours: invite.targetHours,
    password: "",
    status: "active",

    attackerUid: invite.fromUid,
    attackerName: invite.fromUsername,
    attackerConfirmed: false,
    attackerConfirmedAt: null,
    attackerLeft: false,
    attackerLeftAt: null,

    defenderUid: currentUser.uid,
    defenderName: currentData.username,
    defenderConfirmed: false,
    defenderConfirmedAt: null,
    defenderLeft: false,
    defenderLeftAt: null,

    participants: [invite.fromUid, currentUser.uid],

    createdAt: Date.now(),
    startedAt: Date.now(),
    endedAt: null,
    scorecard: null
  });

  await ref.update({
    status: "accepted",
    acceptedAt: Date.now(),
    roomId: roomId
  });

  currentRoomId = roomId;
  currentRoomRole = "defender";

  showBattleScreen();
  showActiveRoom(roomId);
}

window.acceptBattleInvite = acceptBattleInvite;

async function declineBattleInvite(inviteId){
  await db.collection("battleInvites").doc(inviteId).update({
    status: "declined",
    declinedAt: Date.now()
  });

  await loadBattleInvites();
}

window.declineBattleInvite = declineBattleInvite;
async function autoEndBattleIfDeadlinePassed(room){
  if (!currentRoomId) return;
  if (room.status === "ended") return;

  const now = Date.now();

  const targetMs = room.targetHours * 60 * 60 * 1000;
  const battleEndAt = room.startedAt + targetMs;
  const confirmDeadlineAt =
    room.confirmDeadlineAt || battleEndAt + (10 * 60 * 1000);

  if (now < confirmDeadlineAt) return;

  const roomRef =
    db.collection("battleRooms").doc(currentRoomId);

  const freshSnap = await roomRef.get();

  if (!freshSnap.exists) return;

  const freshRoom = freshSnap.data();

  if (freshRoom.status === "ended") return;

  const scorecard = await buildScorecardWithEffects(freshRoom);

  await roomRef.update({
    status: "ended",
    endedAt: Date.now(),
    scorecard: scorecard
  });
}
let selectedProfileFriend = null;

async function openFriendProfile(friendUid){
  const snap = await db.collection("users").doc(friendUid).get();

  if(!snap.exists){
    alert("Friend profile not found");
    return;
  }

  const data = snap.data();

  selectedProfileFriend = {
    uid: friendUid,
    username: data.username
  };

  document.getElementById("friendProfileName").innerText =
    data.username || "Friend";

  document.getElementById("friendProfileLevel").innerText =
    data.level || 1;

  document.getElementById("friendProfileStudy").innerText =
    (data.totalStudyMinutes || 0) + "m";

  document.getElementById("friendProfileCastle").innerText =
    (data.castleHealth || 100) + "%";

  document.getElementById("friendProfileArmy").innerText =
    data.armyPower || 0;

  document.getElementById("friendProfileInviteBtn").onclick = function(){
    closeFriendProfile();

    inviteFriendToBattle(
      selectedProfileFriend.uid,
      selectedProfileFriend.username
    );
  };

  document.getElementById("friendProfileModal")
    .classList.remove("hiddenPage");
}

window.openFriendProfile = openFriendProfile;

function closeFriendProfile(){
  document.getElementById("friendProfileModal")
    .classList.add("hiddenPage");
}

window.closeFriendProfile = closeFriendProfile;
function showSessionComplete(){
  const box = document.createElement("div");

  box.className = "sessionToast";
  box.innerHTML = `
    <div>
      <span>SESSION COMPLETE</span>
      <h3>Focus reward added</h3>
      <p>Your XP, coins, and study progress are updated.</p>

      <button class="primaryBtn" onclick="finishSessionToast(this)">
        Continue
      </button>
    </div>
  `;

  document.body.appendChild(box);
}

function finishSessionToast(button){
  const box = button.closest(".sessionToast");
  if(box) box.remove();

  closeTimer();
}

window.finishSessionToast = finishSessionToast;
async function quitSoloSession(){
  if(!timerRunning) return;

  clearInterval(timerInterval);
  timerRunning = false;

  const deadTrees = (currentData.deadTrees || 0) + 1;

const oldForestTrees =
    currentData.forestTrees || [];

  let updatedForestTrees = oldForestTrees;

  if(oldForestTrees.length < forestSpots.length){
    const spot = forestSpots[oldForestTrees.length];

    updatedForestTrees = [
      ...oldForestTrees,
      {
        id: Date.now().toString(),
        type: "dead",
        x: spot.x,
        y: spot.y,
        minutes: 0,
        createdAt: Date.now()
      }
    ];
  }

  await db.collection("users").doc(currentUser.uid).update({
    deadTrees: deadTrees,
    forestTrees: updatedForestTrees
  });

  await loadUserData();

  timerSeconds = selectedMinutes * 60;
  updateTimerDisplay();

  document.getElementById("startTimerBtn").classList.remove("hiddenPage");
  document.getElementById("quitSoloBtn").classList.add("hiddenPage");

  showSessionFailed();
}

window.quitSoloSession = quitSoloSession;
function showSessionFailed(){
  const box = document.createElement("div");

  box.className = "sessionToast";
  box.innerHTML = `
    <div>
      <span>SESSION FAILED</span>
      <h3>Dead tree added</h3>
      <p>No XP or coins were earned because the session was left early.</p>

      <button class="primaryBtn" onclick="this.closest('.sessionToast').remove()">
        Continue
      </button>
    </div>
  `;

  document.body.appendChild(box);
}

function calculateLevel(totalXP){
  return Math.floor(Math.sqrt(totalXP / 50)) + 1;
}
function getXPRequired(level){
  return level * level * 50;
}
function getXPForSession(minutes){
  return Math.round(minutes);
}
function getTodayDateString(){

  const now = new Date();

  return (
    now.getFullYear() + "-" +
    String(now.getMonth() + 1).padStart(2,"0") + "-" +
    String(now.getDate()).padStart(2,"0")
  );
}
async function buildScorecardWithEffects(room){

  const scorecard = buildScorecard(room);

  if(!room.attackerUid || !room.defenderUid){
    return scorecard;
  }

  const attackerRef = db.collection("users").doc(room.attackerUid);

  const defenderRef = db.collection("users").doc(room.defenderUid);

  const attackerSnap = await attackerRef.get();
  const defenderSnap = await defenderRef.get();

  if(!attackerSnap.exists || !defenderSnap.exists){
    return scorecard;
  }

  const attacker = attackerSnap.data();
  const defender = defenderSnap.data();

  const targetMinutes = Math.round((room.targetHours || 0) * 60);

const battleRewards = calculateBattleRewards(room.targetHours);
const isRewardEligible = targetMinutes >= 15;
const winBonusXP = isRewardEligible ? 100 : 0;
const winBonusCoins = isRewardEligible ? 100 : 0;

  let attackerXP = 0;
  let defenderXP = 0;
  let attackerCoins = 0;
  let defenderCoins = 0;

  let attackerArmyLoss = 0;
  let defenderCastleDamage = 0;

  const attackerConfirmed = room.attackerConfirmed === true;
  const defenderConfirmed = room.defenderConfirmed === true;

  const attackerPower = attacker.armyPower || 0;
  const defenderDefense = defender.castleDefense || 100;

  let damage = Math.round((attackerPower - defenderDefense) / 5);

  if(damage < 5) damage = 5;
  if(damage > 35) damage = 35;

  if(attackerConfirmed && !defenderConfirmed){
    attackerXP = battleRewards.xp;
attackerCoins = battleRewards.coins;

    defenderCastleDamage = damage;

    await attackerRef.update({
      totalXP: (attacker.totalXP || 0) + attackerXP,
      coins: (attacker.coins || 0) + attackerCoins,
      level: calculateLevel((attacker.totalXP || 0) + attackerXP)
    });

    await defenderRef.update({
      castleHealth: Math.max(0, (defender.castleHealth || 100) - defenderCastleDamage)
    });
  }

  else if(!attackerConfirmed && defenderConfirmed){
    defenderXP = battleRewards.xp;
defenderCoins = battleRewards.coins;

    attackerArmyLoss = 10;

    await defenderRef.update({
      totalXP: (defender.totalXP || 0) + defenderXP,
      coins: (defender.coins || 0) + defenderCoins,
      level: calculateLevel((defender.totalXP || 0) + defenderXP)
    });

    await attackerRef.update({
      armyPower: Math.max(0, (attacker.armyPower || 0) - attackerArmyLoss)
    });
  }

  else if(attackerConfirmed && defenderConfirmed){
    attackerXP = Math.floor(battleRewards.xp * 0.8);
defenderXP = battleRewards.xp;

attackerCoins = Math.floor(battleRewards.coins * 0.8);
defenderCoins = battleRewards.coins;

    attackerArmyLoss = 5;

    await attackerRef.update({
      totalXP: (attacker.totalXP || 0) + attackerXP,
      coins: (attacker.coins || 0) + attackerCoins,
      armyPower: Math.max(0, (attacker.armyPower || 0) - attackerArmyLoss),
      level: calculateLevel((attacker.totalXP || 0) + attackerXP)
    });

    await defenderRef.update({
      totalXP: (defender.totalXP || 0) + defenderXP,
      coins: (defender.coins || 0) + defenderCoins,
      level: calculateLevel((defender.totalXP || 0) + defenderXP)
    });
  }

  scorecard.attackerXP = attackerXP;
  scorecard.defenderXP = defenderXP;
  scorecard.attackerCoins = attackerCoins;
  scorecard.defenderCoins = defenderCoins;
  scorecard.attackerArmyLoss = attackerArmyLoss;
  scorecard.defenderCastleDamage = defenderCastleDamage;

  return scorecard;
}
function getArmyUpgradeCost(){
  const armyPower = currentData.armyPower || 0;
  const upgradeLevel = Math.floor(armyPower / 10);
  return 100 + (upgradeLevel * 50);
}

function getDefenseUpgradeCost(){
  const defense = currentData.castleDefense || 100;
  const upgradeLevel = Math.floor((defense - 100) / 5);
  return 120 + (upgradeLevel * 60);
}

async function upgradeArmy(){
  const cost = getArmyUpgradeCost();

  if((currentData.coins || 0) < cost){
    showToast("Not enough coins");
    return;
  }

  await db.collection("users").doc(currentUser.uid).update({
    coins: (currentData.coins || 0) - cost,
    armyPower: (currentData.armyPower || 0) + 10
  });

  await loadUserData();

  showToast("Army upgraded");
}

window.upgradeArmy = upgradeArmy;

async function upgradeDefense(){
  const cost = getDefenseUpgradeCost();

  if((currentData.coins || 0) < cost){
    showToast("Not enough coins");
    return;
  }

  await db.collection("users").doc(currentUser.uid).update({
    coins: (currentData.coins || 0) - cost,
    castleDefense: (currentData.castleDefense || 100) + 5,
    castleHealth: Math.min(100, (currentData.castleHealth || 100) + 10)
  });

  await loadUserData();

  showToast("Castle defense upgraded");
}

window.upgradeDefense = upgradeDefense;
function showToast(text){
  const toast = document.getElementById("toast");

  if(!toast){
    console.log("Toast missing");
    return;
  }

  toast.innerText = text;
  toast.classList.add("show");

  clearTimeout(window.toastTimer);

  window.toastTimer = setTimeout(function(){
    toast.classList.remove("show");
  }, 2200);
}

window.showToast = showToast;
function getStreakBonusPercent(){

  const streak = currentData?.streak || 0;

  if(streak >= 30) return 25;
  if(streak >= 15) return 15;
  if(streak >= 7) return 10;
  if(streak >= 3) return 5;

  return 0;
}

function getMotivationLine(){

  const streak = currentData?.streak || 0;

  if(streak >= 30){
    return "Legendary consistency ✨";
  }

  if(streak >= 15){
    return "Your kingdom fears no distraction ⚔️";
  }

  if(streak >= 7){
    return "Focus is becoming your identity 🔥";
  }

  if(streak >= 3){
    return "Momentum is building 🌿";
  }

  return "Small focus creates giant kingdoms ⚔️";
}

function updateSessionPreview(){

  const mins = selectedMinutes;

  let xp =
    getXPForSession(mins);

  let coins =
    Math.floor(mins * 1.5);

  let tree = "Seed";

  if(mins >= 30){
    tree = "Young Tree";
  }

  if(mins >= 60){
    tree = "Full Tree";
  }

  if(mins >= 120){
    tree = "Rare Tree";
  }

  const streakBonus =
    getStreakBonusPercent();

  xp += Math.floor(
    xp * (streakBonus / 100)
  );

  document.getElementById("previewXP").innerText =
    xp + " XP";

  document.getElementById("previewCoins").innerText =
    coins;

  document.getElementById("previewTree").innerText =
    tree;

  document.getElementById("previewStreak").innerText =
    "+" + streakBonus + "%";

  document.getElementById("motivationLine").innerText =
    getMotivationLine();
}

function calculateBattleRewards(hours){

  const mins = Number(hours) * 60;

  if(mins < 15){
    return {
      xp: 0,
      coins: 0
    };
  }

  let xp = Math.floor(mins * 1.8);
  let coins = Math.floor(mins * 0.9);

  if(mins >= 120){
    xp += 80;
    coins += 40;
  }

  return {
    xp,
    coins
  };
}
function showRewardModal(data){
  document.getElementById("rewardMinutes").innerText =
    data.minutes + " min";

  document.getElementById("rewardXP").innerText =
    "+" + data.xp;

  document.getElementById("rewardCoins").innerText =
    "+" + data.coins;

  document.getElementById("rewardTree").innerText =
    data.tree;

  document.getElementById("rewardStreak").innerText =
    "+" + data.streakBonus + "%";

  document.getElementById("rewardModal")
    .classList.remove("hiddenPage");
}

function closeRewardModal(){
  document.getElementById("rewardModal")
    .classList.add("hiddenPage");

  closeTimer();
}

window.closeRewardModal = closeRewardModal;

const TREE_ASSETS = {
  seed: "assets/trees/seed.png",
  young: "assets/trees/young.png",
  full: "assets/trees/full.png",
  rare: "assets/trees/rare.png",
  legendary: "assets/trees/legendary.png",
  dead: "assets/trees/dead.png"
};

const forestSpots = [
  {x:220,y:560},{x:310,y:610},{x:420,y:535},{x:520,y:630},{x:640,y:555},
  {x:760,y:620},{x:880,y:545},{x:1010,y:640},{x:1120,y:560},{x:1240,y:630},
  {x:1360,y:545},{x:1490,y:620},{x:1610,y:555},{x:1720,y:635},

  {x:260,y:720},{x:370,y:780},{x:480,y:700},{x:590,y:790},{x:720,y:710},
  {x:830,y:805},{x:950,y:725},{x:1070,y:800},{x:1180,y:710},{x:1300,y:790},
  {x:1420,y:720},{x:1540,y:800},{x:1660,y:720},

  {x:210,y:880},{x:330,y:950},{x:450,y:870},{x:570,y:960},{x:690,y:880},
  {x:810,y:950},{x:930,y:870},{x:1050,y:960},{x:1170,y:880},{x:1290,y:950},
  {x:1410,y:870},{x:1530,y:960},{x:1650,y:880},

  {x:250,y:1060},{x:380,y:1130},{x:510,y:1040},{x:640,y:1140},{x:770,y:1060},
  {x:900,y:1130},{x:1030,y:1040},{x:1160,y:1140},{x:1290,y:1060},{x:1420,y:1130},
  {x:1550,y:1040},{x:1680,y:1140},

  {x:300,y:1240},{x:430,y:1320},{x:560,y:1220},{x:690,y:1330},{x:820,y:1240},
  {x:950,y:1320},{x:1080,y:1220},{x:1210,y:1330},{x:1340,y:1240},{x:1470,y:1320},
  {x:1600,y:1220},

  {x:240,y:1450},{x:390,y:1510},{x:540,y:1430},{x:690,y:1530},{x:840,y:1450},
  {x:990,y:1510},{x:1140,y:1430},{x:1290,y:1530},{x:1440,y:1450},{x:1590,y:1510},

  {x:260,y:1650},{x:430,y:1700},{x:600,y:1620},{x:770,y:1720},{x:940,y:1650},
  {x:1110,y:1700},{x:1280,y:1620},{x:1450,y:1720},{x:1620,y:1650},

  {x:350,y:1850},{x:520,y:1930},{x:690,y:1840},{x:860,y:1940},{x:1030,y:1850},
  {x:1200,y:1930},{x:1370,y:1840},{x:1540,y:1940},

  {x:280,y:2080},{x:470,y:2160},{x:660,y:2070},{x:850,y:2170},{x:1040,y:2080},
  {x:1230,y:2160},{x:1420,y:2070},{x:1610,y:2170},

  {x:360,y:2320},{x:570,y:2410},{x:780,y:2310},{x:990,y:2420},{x:1200,y:2320},
  {x:1410,y:2410},{x:1620,y:2320}
];

function getTreeTypeFromMinutes(minutes){
  if(minutes >= 300) return "legendary";
  if(minutes >= 120) return "rare";
  if(minutes >= 60) return "full";
  if(minutes >= 30) return "young";
  if(minutes >= 15) return "seed";
  return null;
}

function getUserForestTrees(){
  return currentData?.forestTrees || [];
}

async function addTreeToForest(type, minutes){
  if(!currentUser || !type) return;

  const oldTrees = getUserForestTrees();

  if(oldTrees.length >= forestSpots.length){
    showToast("Forest zone full. New zone needed soon.");
    return;
  }

  const spot = forestSpots[oldTrees.length];

  const newTree = {
    id: Date.now().toString(),
    type: type,
    x: spot.x,
    y: spot.y,
    minutes: minutes || 0,
    createdAt: Date.now()
  };

  const updatedTrees = [
    ...oldTrees,
    newTree
  ];

  await db.collection("users").doc(currentUser.uid).update({
    forestTrees: updatedTrees
  });

  currentData.forestTrees = updatedTrees;
  renderForestTrees();
}

function renderForestTrees(){
  const layer = document.getElementById("treeLayer");
  if(!layer || !currentData) return;

  const savedTrees = currentData.forestTrees || [];
  const trees = [];

  const livingCount = currentData.trees || 0;
  const deadCount = currentData.deadTrees || 0;

  const naturalSpots = [
    {x:28,y:76},{x:40,y:72},{x:53,y:75},{x:66,y:72},{x:78,y:76},
    {x:32,y:82},{x:46,y:85},{x:60,y:82},{x:73,y:86},{x:84,y:82},
    {x:26,y:90},{x:39,y:92},{x:52,y:90},{x:65,y:93},{x:79,y:90},
    {x:34,y:67},{x:48,y:64},{x:62,y:66},{x:75,y:64},{x:86,y:68}
  ];

  for(let i = 0; i < livingCount; i++){
    const spot = naturalSpots[i % naturalSpots.length];
    trees.push({
      id:"old-living-" + i,
      type:"full",
      xPercent:spot.x,
      yPercent:spot.y,
      minutes:60,
      createdAt:currentData.createdAt || Date.now()
    });
  }

  for(let i = 0; i < deadCount; i++){
    const spot = naturalSpots[(livingCount + i) % naturalSpots.length];
    trees.push({
      id:"old-dead-" + i,
      type:"dead",
      xPercent:spot.x,
      yPercent:spot.y,
      minutes:0,
      createdAt:currentData.createdAt || Date.now()
    });
  }

  savedTrees.forEach((tree, i) => {
    const spot = naturalSpots[(trees.length + i) % naturalSpots.length];
    trees.push({
      ...tree,
      xPercent:spot.x,
      yPercent:spot.y
    });
  });

  layer.innerHTML = "";

  trees.forEach(tree => {
    const img = document.createElement("img");

    img.src = TREE_ASSETS[tree.type] || TREE_ASSETS.seed;
    img.className = "mapTree " + tree.type;

    img.style.left = tree.xPercent + "%";
    img.style.top = tree.yPercent + "%";

    img.onclick = function(){
      showTreeInfo(tree);
    };

    layer.appendChild(img);
  });
}

function showTreeInfo(tree){
  const date = new Date(tree.createdAt || Date.now());

  const dateText = date.toLocaleDateString([], {
    day: "numeric",
    month: "short",
    year: "numeric"
  });

  const typeName =
    tree.type.charAt(0).toUpperCase() + tree.type.slice(1);

  showToast(
    typeName +
    " Tree • " +
    (tree.minutes || 0) +
    " min • " +
    dateText
  );
}

let pixelPlayerX = 680;
let pixelPlayerY = 700;

async function openPixelForest(){
  const game = document.getElementById("pixelForestGame");
  game.classList.remove("hiddenPage");

  try{
    if(game.requestFullscreen) await game.requestFullscreen();
    if(screen.orientation && screen.orientation.lock){
      await screen.orientation.lock("landscape");
    }
  }catch(e){
    console.log("Orientation lock:", e.message);
  }

  setupJoystick();
  updatePixelCamera();
}

window.openPixelForest = openPixelForest;

function closePixelForest(){
  document.getElementById("pixelForestGame").classList.add("hiddenPage");

  try{
    if(document.fullscreenElement) document.exitFullscreen();
  }catch(e){}

  if(joyLoop) clearInterval(joyLoop);
}

window.closePixelForest = closePixelForest;

function movePixelPlayer(dx, dy){
  const speed = 34;

  pixelPlayerX += dx * speed;
  pixelPlayerY += dy * speed;

  if(pixelPlayerX < 40) pixelPlayerX = 40;
  if(pixelPlayerY < 90) pixelPlayerY = 90;
  if(pixelPlayerX > 1720) pixelPlayerX = 1720;
  if(pixelPlayerY > 1120) pixelPlayerY = 1120;

  updatePixelCamera();
}

window.movePixelPlayer = movePixelPlayer;

function updatePixelCamera(){
  const player = document.getElementById("pixelPlayer");
  const world = document.getElementById("pixelWorld");
  const miniPlayer = document.getElementById("miniPlayer");

  if(!player || !world) return;

  const zoom = window._pixelZoom || 0.78;

  player.style.left = pixelPlayerX + "px";
  player.style.top = pixelPlayerY + "px";

  const screenW = window.innerWidth;
  const screenH = window.innerHeight;

  let camX = (screenW / 2) - (pixelPlayerX * zoom);
  let camY = (screenH / 2) - (pixelPlayerY * zoom);

  const worldW = 1800 * zoom;
  const worldH = 1200 * zoom;

  camX = Math.min(0, Math.max(camX, screenW - worldW));
  camY = Math.min(0, Math.max(camY, screenH - worldH));

  world.style.transformOrigin = "top left";
  world.style.transform = `translate(${camX}px,${camY}px) scale(${zoom})`;

  if(miniPlayer){
    miniPlayer.style.left = ((pixelPlayerX / 1800) * 100) + "%";
    miniPlayer.style.top = ((pixelPlayerY / 1200) * 100) + "%";
  }
}

function interactPixelWorld(){
  showToast("Tree interaction coming next");
}

window.interactPixelWorld = interactPixelWorld;

function openTreeInventory(){
  showToast("Inventory system coming next");
}

window.openTreeInventory = openTreeInventory;

// PIXEL GAME GLOBALS
window._pixelZoom = 0.78;
let joyActive = false;
let joyDX = 0;
let joyDY = 0;
let joyLoop = null;

function setupJoystick(){
  const stick = document.getElementById("joyStick");
  const knob = document.getElementById("joyKnob");

  if(!stick || !knob) return;

  let active = false;

  function setJoy(clientX, clientY){
    const rect = stick.getBoundingClientRect();

    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    let dx = clientX - cx;
    let dy = clientY - cy;

    const max = 46;
    const dist = Math.hypot(dx, dy);

    if(dist > max){
      dx = dx / dist * max;
      dy = dy / dist * max;
    }

    knob.style.transform = `translate(${dx}px, ${dy}px)`;

    joyDX = dx / max;
    joyDY = dy / max;
  }

  stick.onpointerdown = function(e){
    active = true;
    stick.setPointerCapture(e.pointerId);
    setJoy(e.clientX, e.clientY);

    if(joyLoop) clearInterval(joyLoop);

    joyLoop = setInterval(() => {
      if(!active) return;

      pixelPlayerX += joyDX * 6;
      pixelPlayerY += joyDY * 6;

      pixelPlayerX = Math.max(40, Math.min(1720, pixelPlayerX));
      pixelPlayerY = Math.max(90, Math.min(1120, pixelPlayerY));

      updatePixelCamera();
    }, 16);
  };

  stick.onpointermove = function(e){
    if(!active) return;
    setJoy(e.clientX, e.clientY);
  };

  stick.onpointerup = function(){
    active = false;
    joyDX = 0;
    joyDY = 0;
    knob.style.transform = "translate(0,0)";
  };

  stick.onpointercancel = stick.onpointerup;
}
